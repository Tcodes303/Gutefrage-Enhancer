// Benutzername, durch deinen eigenen Gutefrage-Benutzernamen ersetzen
const myUsername = 'DeinBenutzername';

// Funktion, um deine Antwort nach oben zu verschieben
function highlightMyAnswer() {
    const answers = document.querySelectorAll('.answer'); // alle Antworten suchen (Klassennamen könnte variieren)
    answers.forEach(answer => {
        const usernameElement = answer.querySelector('.username'); // Benutzername des Antwortenden
        if (usernameElement && usernameElement.innerText.includes(myUsername)) {
            // Antwort hervorheben (z.B. durch einen Rahmen)
            answer.style.border = '2px solid gold';
            // Antwort an den Anfang der Liste verschieben
            const parent = answer.parentElement;
            parent.prepend(answer);
        }
    });
}

// Funktion, um Fragen in der Übersicht zu markieren, auf die du geantwortet hast
function markAnsweredQuestions() {
    const questionList = document.querySelectorAll('.question-list-item'); // alle Fragen in der Übersicht
    questionList.forEach(question => {
        const answeredByMe = question.querySelector(`.answer-author:contains("${myUsername}")`); // prüfen, ob du geantwortet hast
        if (answeredByMe) {
            // Frage mit einem Qualitätssiegel markieren
            const qualityBadge = document.createElement('span');
            qualityBadge.innerText = '✓ Qualifizierte Antwort';
            qualityBadge.style.color = 'green';
            question.querySelector('.question-title').appendChild(qualityBadge); // Badge an die Frage anhängen
        }
    });
}

// Wenn die Seite vollständig geladen ist, führe die Funktionen aus
window.onload = () => {
    highlightMyAnswer();
    markAnsweredQuestions();
};
